function 1st method
function additionTwoNumber(x,y,z){

    var total =x+y+z;
    return total;
}

console.log(additionTwoNumber(50,50,50))


// // 2nd method
// function additionTwoNumber(x,y,z){

//     var total =x+y+z;
// console.log(total)
// }
// additionTwoNumber(10,50,40);

// function myFunction(){
// var num1=Number(document.getElementById('num1'));
// var num2=Number(document.getElementById('num2'));
// var total =num1.value+num2.value;
// document.write(total);

// }


